const { kafka } = require("./client");

async function init() {
  const producer = kafka.producer();

  console.log("Connecting producer");
  await producer.connect();
  console.log("Producer is connected");

  await producer.send({
    topic: "rider-updated", //means on which topic we have to send
    messages: [{ partition: 0, key: "name", value: "Prajwal" }],
  });

 await producer.disconnect();
}

init();